# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [2.0.1](https://github.com/AnthonyLzq/ocr-space-api2/compare/v2.0.0...v2.0.1) (2021-12-25)


### Bug Fixes

* fixed docs ([1e28f8f](https://github.com/AnthonyLzq/ocr-space-api2/commit/1e28f8f74e52baf8e9e38648997d967dff3e3bb8))

## 2.0.0 (2021-12-25)


### Features

* added support for typescript ([f63c3c1](https://github.com/AnthonyLzq/ocr-space-api2/commit/f63c3c1249bc2e29c11f32d4131d54eda8580e25))
